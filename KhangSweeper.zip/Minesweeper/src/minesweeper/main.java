/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package minesweeper;
import java.text.ParseException;
import javax.swing.JOptionPane;
/**
 *
 * @author ASUS rog strix
 Zur Hilfe genommen habe ich mein PromillenRechner, BBBGame und diesen Github https://github.com/Squirrelbear/main/blob/main/main/src/main/
 */
public class main{
  public static void main(String[] args) {
    GameFunctions.run();
  }
  
 
}
